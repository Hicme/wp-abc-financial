<div class="wrap">
    <div class="top_tab">
        <?php $this->get_tab_link(); ?>
    </div>

    <div class="content_tab">
        <?php do_action( 'wpadbcf_settings_tab_content' ); ?>
    </div>
</div>
